En los dos ejercicios del SIMLAB, se ha eliminado parte del control de errores para facilitar la lectura.

El programa lee_ints.c os puede servir para comprobar los datos escritos en el fichero username.dat.
Lee de la entrada estandar valores enteros en formato interno de maquina (binario, tipo entero) y los muestra como cadenas de caracteres entendibles por los humanos (valor en ASCII)

